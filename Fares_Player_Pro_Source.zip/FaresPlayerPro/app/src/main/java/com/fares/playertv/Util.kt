package com.fares.playertv

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Account(val server: String, val user: String, val pass: String)
data class Channel(val name: String, val url: String, val streamId: String = "", val icon: String = "")

object Playlist { var items: List<Channel> = emptyList(); var index = 0 }

object Store {
    fun load(c: Context): MutableList<Account> {
        val s = c.getSharedPreferences("p", 0).getString("accounts", "[]")!!
        val a = JSONArray(s)
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Account(o.getString("s"), o.getString("u"), o.getString("p"))
        }
    }
    fun save(c: Context, l: List<Account>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("s", it.server).put("u", it.user).put("p", it.pass)) }
        c.getSharedPreferences("p", 0).edit().putString("accounts", a.toString()).apply()
    }
    private fun hiddenKey(a: Account) = "hidden_${a.server}_${a.user}"
    fun hidden(c: Context, a: Account): Set<String> =
        c.getSharedPreferences("hidden_channels", 0).getStringSet(hiddenKey(a), emptySet())?.toSet() ?: emptySet()
    fun saveHidden(c: Context, a: Account, values: Set<String>) {
        c.getSharedPreferences("hidden_channels", 0).edit().putStringSet(hiddenKey(a), values.toSet()).apply()
    }
    private fun favoriteKey(a: Account) = "favorites_${a.server}_${a.user}"
    fun favorites(c: Context, a: Account): Set<String> =
        c.getSharedPreferences("favorite_channels", 0).getStringSet(favoriteKey(a), emptySet())?.toSet() ?: emptySet()
    fun saveFavorites(c: Context, a: Account, values: Set<String>) {
        c.getSharedPreferences("favorite_channels", 0).edit().putStringSet(favoriteKey(a), values.toSet()).apply()
    }
}

object Xtream {
    fun normalize(s: String): String {
        var t = s.trim().trimEnd('/')
        if (!t.startsWith("http://") && !t.startsWith("https://")) t = "http://$t"
        return t
    }
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "FaresPlayerTV/1.0")
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }
    private fun api(a: Account, action: String, extra: String = "") =
        "${a.server}/player_api.php?username=${Uri.encode(a.user)}&password=${Uri.encode(a.pass)}&action=$action$extra"

    fun categories(a: Account): List<Pair<String, String>> {
        val j = JSONArray(get(api(a, "get_live_categories")))
        return List(j.length()) { j.getJSONObject(it).let { o -> o.getString("category_id") to o.getString("category_name") } }
    }
    fun channels(a: Account, catId: String?): List<Channel> {
        val extra = if (catId == null) "" else "&category_id=$catId"
        val j = JSONArray(get(api(a, "get_live_streams", extra)))
        return List(j.length()) {
            val o = j.getJSONObject(it)
            val id = o.get("stream_id").toString()
            Channel(o.getString("name"),
                "${a.server}/live/${Uri.encode(a.user)}/${Uri.encode(a.pass)}/$id.ts",
                id, o.optString("stream_icon", ""))
        }
    }
}

class RowAdapter(
    var items: List<String>,
    val onClick: (Int) -> Unit,
    val onLong: ((Int) -> Unit)? = null
) : RecyclerView.Adapter<RowAdapter.VH>() {
    class VH(val t: TextView) : RecyclerView.ViewHolder(t)
    override fun onCreateViewHolder(p: ViewGroup, v: Int): VH {
        val view = LayoutInflater.from(p.context).inflate(R.layout.item_row, p, false) as TextView
        val horizontal = p.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT
        view.layoutParams = RecyclerView.LayoutParams(
            if (horizontal) ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        view.setPadding(18, view.paddingTop, 18, view.paddingBottom)
        return VH(view)
    }
    override fun onBindViewHolder(h: VH, i: Int) {
        h.t.text = items[i]
        h.t.setOnClickListener { val p = h.bindingAdapterPosition; if (p != RecyclerView.NO_POSITION) onClick(p) }
        h.t.setOnLongClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onLong?.invoke(p)
            onLong != null
        }
    }
    override fun getItemCount() = items.size
}

class ChannelAdapter(
    var items: List<Channel>,
    private val onPlay: (Channel) -> Unit,
    private val onToggleHidden: (Channel) -> Unit,
    private val onToggleFavorite: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {
    var hiddenMode = false
    var favoriteIds: Set<String> = emptySet()
    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvChannelName)
        val action: ImageButton = v.findViewById(R.id.btnChannelVisibility)
        val favorite: ImageButton = v.findViewById(R.id.btnChannelFavorite)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) {
        val channel = items[position]
        holder.name.text = channel.name
        holder.itemView.setOnClickListener { onPlay(channel) }
        holder.action.contentDescription = if (hiddenMode) "إظهار القناة" else "إخفاء القناة"
        holder.action.setImageResource(if (hiddenMode) android.R.drawable.ic_menu_view else android.R.drawable.ic_menu_close_clear_cancel)
        holder.action.setOnClickListener { onToggleHidden(channel) }
        val favorite = channel.url in favoriteIds
        holder.favorite.setImageResource(if (favorite) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off)
        holder.favorite.contentDescription = if (favorite) "إزالة من المفضلة" else "إضافة للمفضلة"
        holder.favorite.setOnClickListener { onToggleFavorite(channel) }
    }
    override fun getItemCount() = items.size
}
