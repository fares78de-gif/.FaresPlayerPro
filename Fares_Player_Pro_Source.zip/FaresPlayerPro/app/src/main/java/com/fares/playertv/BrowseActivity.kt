package com.fares.playertv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class BrowseActivity : Activity() {
    private lateinit var acc: Account
    private var cats: List<Pair<String?, String>> = emptyList()
    private var allChannels: List<Channel> = emptyList()
    private var showingHidden = false
    private var showingFavorites = false
    private var selectedCategory: String? = null
    private var selectedChannel: Channel? = null
    private lateinit var channelAdapter: ChannelAdapter
    private lateinit var title: TextView
    private lateinit var empty: TextView
    private lateinit var search: EditText
    private lateinit var btnAll: Button
    private lateinit var btnFavorites: Button
    private lateinit var btnHidden: Button
    private lateinit var preview: PlayerView
    private var previewPlayer: ExoPlayer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_browse)
        acc = Account(intent.getStringExtra("s")!!, intent.getStringExtra("u")!!, intent.getStringExtra("p")!!)
        title = findViewById(R.id.tvSectionTitle)
        empty = findViewById(R.id.tvEmpty)
        search = findViewById(R.id.etSearch)
        btnAll = findViewById(R.id.btnAll)
        btnFavorites = findViewById(R.id.btnFavorites)
        btnHidden = findViewById(R.id.btnHidden)
        preview = findViewById(R.id.previewPlayer)
        preview.useController = false

        channelAdapter = ChannelAdapter(emptyList(), { channel -> playPreview(channel) },
            { channel -> toggleHidden(channel) }, { channel -> toggleFavorite(channel) })
        findViewById<RecyclerView>(R.id.rvChannels).apply {
            layoutManager = LinearLayoutManager(this@BrowseActivity)
            adapter = channelAdapter
            setHasFixedSize(true)
        }
        val catAdapter = RowAdapter(listOf("Toutes les chaînes"), { i ->
            selectedCategory = if (i == 0) null else cats.getOrNull(i)?.first
            showingHidden = false; showingFavorites = false
            updateTabs()
            if (selectedCategory == null) renderChannels() else loadCategory(selectedCategory!!)
        })
        findViewById<RecyclerView>(R.id.rvCats).apply {
            val horizontal = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT
            layoutManager = LinearLayoutManager(this@BrowseActivity, if (horizontal) RecyclerView.HORIZONTAL else RecyclerView.VERTICAL, false)
            adapter = catAdapter
        }
        btnAll.setOnClickListener { showingHidden = false; showingFavorites = false; selectedCategory = null; updateTabs(); renderChannels() }
        btnFavorites.setOnClickListener { showingHidden = false; showingFavorites = true; selectedCategory = null; updateTabs(); renderChannels() }
        btnHidden.setOnClickListener { showingHidden = true; showingFavorites = false; selectedCategory = null; updateTabs(); renderChannels() }
        findViewById<View>(R.id.btnFullscreen).setOnClickListener { openFullPlayer() }
        findViewById<View>(R.id.btnRefresh).setOnClickListener { loadChannels() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderChannels() }
            override fun afterTextChanged(s: Editable?) {}
        })

        Thread {
            try {
                val c = listOf<Pair<String?, String>>(null to "Toutes") + Xtream.categories(acc)
                val l = Xtream.channels(acc, null)
                runOnUiThread {
                    cats = c
                    catAdapter.items = c.map { it.second }
                    catAdapter.notifyDataSetChanged()
                    allChannels = l
                    renderChannels()
                    findViewById<TextView>(R.id.tvAccountName).text = acc.user
                    findViewById<TextView>(R.id.tvChannelCount).text = "${l.size} chaînes disponibles"
                }
            } catch (e: Exception) { toast("Erreur serveur : ${e.message}") }
        }.start()
        updateTabs()
    }

    override fun onStart() {
        super.onStart()
        previewPlayer = ExoPlayer.Builder(this).build().also { preview.player = it }
        selectedChannel?.let { playPreview(it) }
    }

    private fun displayedChannels(): List<Channel> {
        val hidden = Store.hidden(this, acc)
        val favorites = Store.favorites(this, acc)
        var source = when {
            showingHidden -> allChannels.filter { it.url in hidden }
            showingFavorites -> allChannels.filter { it.url in favorites && it.url !in hidden }
            else -> allChannels.filter { it.url !in hidden }
        }
        if (!showingHidden && !showingFavorites && selectedCategory != null) {
            // Categories are fetched by the provider; keep the full list available for quick filtering.
            val categoryChannels = categoryCache[selectedCategory]
            if (categoryChannels != null) source = source.filter { item -> categoryChannels.any { it.url == item.url } }
        }
        val q = search.text.toString().trim()
        return if (q.isEmpty()) source else source.filter { it.name.contains(q, ignoreCase = true) }
    }

    private val categoryCache = mutableMapOf<String, List<Channel>>()

    private fun loadCategory(id: String) {
        if (categoryCache.containsKey(id)) { renderChannels(); return }
        Thread {
            try {
                val result = Xtream.channels(acc, id)
                runOnUiThread { categoryCache[id] = result; renderChannels() }
            } catch (e: Exception) { toast("تعذر تحميل التصنيف: ${e.message}") }
        }.start()
    }

    private fun renderChannels() {
        val list = displayedChannels()
        channelAdapter.items = list
        channelAdapter.hiddenMode = showingHidden
        channelAdapter.favoriteIds = Store.favorites(this, acc)
        channelAdapter.notifyDataSetChanged()
        empty.visibility = if (list.isEmpty()) TextView.VISIBLE else TextView.GONE
        empty.text = when { showingHidden -> "لا توجد قنوات مخفية"; showingFavorites -> "لم تضف قنوات للمفضلة بعد"; else -> "لم يتم العثور على قنوات" }
        title.text = when { showingHidden -> "القنوات المخفية"; showingFavorites -> "قنواتي المفضلة"; selectedCategory != null -> cats.firstOrNull { it.first == selectedCategory }?.second ?: "القنوات"; else -> "كل القنوات المباشرة" }
        findViewById<TextView>(R.id.tvChannelCount).text = "${list.size} قناة"
    }

    private fun playPreview(channel: Channel) {
        selectedChannel = channel
        val p = previewPlayer ?: return
        try {
            p.setMediaItem(MediaItem.fromUri(channel.url)); p.prepare(); p.playWhenReady = true
            findViewById<TextView>(R.id.tvNowPlaying).text = channel.name
            val visible = displayedChannels()
            Playlist.items = if (visible.isEmpty()) allChannels else visible
            Playlist.index = Playlist.items.indexOfFirst { it.url == channel.url }.coerceAtLeast(0)
        } catch (e: Exception) { toast("تعذر تشغيل القناة") }
    }

    private fun openFullPlayer() {
        if (Playlist.items.isEmpty()) {
            val list = displayedChannels()
            if (list.isEmpty()) { toast("اختر قناة أولاً"); return }
            Playlist.items = list; Playlist.index = 0
        }
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun toggleHidden(channel: Channel) {
        val values = Store.hidden(this, acc).toMutableSet()
        if (channel.url in values) values.remove(channel.url) else values.add(channel.url)
        Store.saveHidden(this, acc, values); renderChannels()
    }

    private fun toggleFavorite(channel: Channel) {
        val values = Store.favorites(this, acc).toMutableSet()
        if (channel.url in values) values.remove(channel.url) else values.add(channel.url)
        Store.saveFavorites(this, acc, values); renderChannels()
    }

    private fun updateTabs() {
        styleTab(btnAll, !showingHidden && !showingFavorites)
        styleTab(btnFavorites, showingFavorites)
        styleTab(btnHidden, showingHidden)
    }

    private fun styleTab(button: Button, active: Boolean) {
        button.setTextColor(if (active) 0xFF17130A.toInt() else 0xFFE5C36B.toInt())
        button.setBackgroundResource(if (active) R.drawable.gold_button else R.drawable.dark_button)
        button.isSelected = active
    }

    override fun onStop() {
        super.onStop()
        preview.player = null
        previewPlayer?.release(); previewPlayer = null
    }

    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }
}
