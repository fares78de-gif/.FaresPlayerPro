# Fares Player Pro

Android IPTV player with an original dark-and-gold interface inspired by IB Player layouts.

- Xtream Codes login and saved accounts
- Live TV categories and channel browsing
- Phone portrait layout and Android TV landscape layout
- Live preview and full-screen playback
- Search, favorites, hide/show channels without PIN
- D-pad friendly focusable controls

## Build
JDK 17 and Gradle 8.7:
```bash
gradle assembleDebug --no-daemon
```

The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`. This app is a player only and does not include channels or playlists. Use an authorized IPTV provider.

The project has not yet been verified by a successful build or on physical devices.
